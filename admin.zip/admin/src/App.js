import {Routes, Route, } from "react-router-dom"
import * as React from 'react'
import Navbar from './Navbar';
import Products from './Products';
import CreateProDucts from './CreateProDucts'
import './App.css'

function App() {
  return (
    <div className="App">
    <div>
      <Navbar />
      <Routes>
        <Route path="/" element={<Products />} />
        <Route path="/Create" element={<CreateProDucts />} />
      </Routes>
    </div>
    </div>
  );
}

export default App;
