//Sutinee Saengtawan
import React from "react";
import Axios from 'axios';
import { useState } from "react";


function App() {

  const [ID, setID] = useState(0);
  const [Name, setName] = useState("");
  const [Price, setPrice] = useState(0);
  const [Type, setType] = useState("");
  const [Stock, setStock] = useState(0);


  const {CreateProductsList, setCreateProductsList} = useState([]);

  

  const addCreateProducts = () => {
    Axios.post('http://localhost:3000/Create?' , {
      ID: ID,
      Name: Name,
      Price: Price,
      Type: Type,
      Stock: Stock

    }).then(() => {
     setCreateProductsList([
      ...CreateProductsList,
      {
        ID: ID,
      Name: Name,
      Price: Price,
      Type: Type,
      Stock: Stock
      }
     ])
    })


  }
 return (
 <div className="App container">
  <h1>AddProducts</h1>
  <div className="Products">
    <form action="">
      <div className="mb-3">
        <label htmlFor="ID" className="form-label">ID</label>
      <input type="number" className="form-control" placeholder="Enter ID"
      onChange={(event) => {
        setID(event.target.value)
      }}
      />
      </div>
      <div className="mb-3">
        <label htmlFor="Name" className="form-label">Name</label>
      <input type="text" className="form-control" placeholder="Enter Name"
      onChange={(event) => {
        setName(event.target.value)
      }}
      />
      </div>
      <div className="mb-3">
        <label htmlFor="Price" className="form-label">Price</label>
      <input type="number" className="form-control" placeholder="Enter Price"
      onChange={(event) => {
        setPrice(event.target.value)
      }}
      />
      </div>
      <div className="mb-3">
        <label htmlFor="Type" className="form-label">Type</label>
      <input type="text" className="form-control" placeholder="Enter Type"
      onChange={(event) => {
        setType(event.target.value)
      }}
      />
      </div>
      <div className="mb-3">
        <label htmlFor="Stock" className="form-label">Stock</label>
      <input type="number" className="form-control" placeholder="Enter Stock"
      onChange={(event) => {
        setStock(event.target.value)
      }}
      />
      </div>
      <button className="btn btn-success" onClick={addCreateProducts}>AddProducts</button>
       </form>
    </div>
    
  </div>
  
 );
}


export default App;