//Sutinee Saengtawan

var express = require('express')
var cors = require('cors')
var app = express()

// get the client
app.use(cors())
const mysql = require('mysql2');

const connection = mysql.createConnection({
  host: 'us-east.connect.psdb.cloud',
  user: 'b92xved1xqbgxfq3309h',
  password: 'pscale_pw_JT8OZ2cffeEEi35r357nYuCTd3ysDWB37KakOTzynIq',
  database: 'sabaipaer',
  port: 3306,
  ssl: {
    rejectUnauthorized: false
  }
});

connection.connect();
app.get('/products', function (req, res, next) {
  connection.query('SELECT  * FROM sabaipaer.`stock`  ', function (error, results, fields) {
      if (error) throw error;
      res.json(results)
    });
})



app.post('/Create?', (req, res) => {
  const Name = req.body.Name;
  const Price = req.body.Price;
  const Type = req.body.Type;
  const Stock = req.body.Stock;

  connection.query('INSERT INTO stock ( Name, Type, Price, Stock) VALUES(?,?,?,?,?)',
   [ Name,  Price, Type, Stock],
     (err, result) => {
        if (err) {
         console.log(err)
        } else{
         res.send("Values inserted");
        }
     }
   );
})


app.listen(4000, function () {
  console.log('CORS-enabled web server listening on port 4000')
})